package ceka.consensus.other.SLLC_paper;


//import ceka.consensus.other.LDELC.CHI;

import ceka.consensus.other.LDELC.CekaUtils;
import ceka.core.*;
import weka.classifiers.Classifier;
import weka.classifiers.trees.RandomForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;

public class SLLC {
	public int m_numExamples;
	public int m_numWorkers;
	public int m_numClasses;
	public int m_numAttributes;

	//boolean[] is_highquality;
	private double[] m_MinArray;
	private double[] m_MaxArray;

	//Worker similarity matrix
	public static double[][] maxtri;

	//Number of similar workers
	public static int numK;

	public double delta;

	public Dataset doInference(Dataset dataset,int K) throws Exception {
		m_numAttributes = dataset.numAttributes();
		m_numExamples = dataset.getExampleSize();
		m_numClasses = dataset.getCategorySize();
		m_numWorkers = dataset.getWorkerSize();

		this.delta = delta;

		Dataset tempDataset = CekaUtils.datasetCopy(dataset);

		m_numWorkers = tempDataset.getWorkerSize();
		System.out.println("--------------------------------------------------------------- ");
		System.out.println("before Number of workers: " + m_numWorkers);

		int[] workercounts = new int[3];
		//为每个工人构建一个数据集

		//统计所有的标签个数
		double lablecount = 0;


		// Construct a dataset for each worker
		HashMap<String,Double> workeracc = new HashMap<String, Double>();
		HashMap<String,Dataset> sub_dataset = new HashMap<String, Dataset>();
		for(int i = 0; i < tempDataset.getExampleSize(); i++) {
			Example example = tempDataset.getExampleByIndex(i);
			lablecount += example.getWorkerIdList().size();
			ArrayList<String> workerList = example.getWorkerIdList();
			for(int j = 0; j < m_numWorkers; j++) {
				String id = tempDataset.getWorkerByIndex(j).getId();
				if(workerList.contains(id) ){
					//if( workerList.contains(id) ){
					if (!sub_dataset.containsKey(id) ) {
						Dataset temp_dataset = new Dataset(tempDataset, 0);
						sub_dataset.put(id, temp_dataset);
					}

					example.setWeight(1.0);
					example.setIntegratedLabel(example.getNoisyLabelByWorkerId(id));

					sub_dataset.get(id).addExample(example);
					//System.out.println("true: " + example.getTrueLabel().getValue() + "  train:  " + example.getTrainingLabel() + "  Label: " + example.getNoisyLabelByWorkerId(id).getValue()  );
					if(example.getNoisyLabelByWorkerId(id).getValue() == example.getTrueLabel().getValue()) {
						if (!workeracc.containsKey(id))
							workeracc.put(id, 0.0);
						workeracc.replace(id, workeracc.get(id) + 1);
					}
				}
			}
		}
		System.out.println(workeracc);
		System.out.println("labelcount: " + lablecount);


		HashMap<String, Classifier> sub_classifier = new HashMap<String, Classifier>();

		// Calculate feature vectors for each worker
		HashMap<String, double[]> attributeW = new HashMap<String, double[]>();
		for (String id : sub_dataset.keySet()) {
			double[] attW = new double[tempDataset.numAttributes()];
			attW = calAttributeW(sub_dataset.get(id), id);
			attributeW.put(id, attW);
		}

		//Calculating worker similarity
		maxtri = new double[tempDataset.getWorkerSize()][tempDataset.getWorkerSize()];

		numK = K;

		//Worker index corresponding to similar workers for each worker
		int[][] similarKWorker = new int[tempDataset.getWorkerSize()][numK];

		//Obtain the worker weights according to the worker similarity
		double[][] distanceWorker = new double[tempDataset.getWorkerSize()][numK];

		HashMap<String, Double> lowquality_before = new HashMap<>();
		HashMap<String, Double> lowquality_after = new HashMap<>();
		HashMap<String, Double> lowquality_count = new HashMap<>();

		HashMap<String, Integer> subdataset_count = new HashMap<>();
		for(int i = 0 ; i < tempDataset.getWorkerSize(); i++) {
			String id = tempDataset.getWorkerByIndex(i).getId();
			subdataset_count.put(id, sub_dataset.get(id).getExampleSize());
		}
		System.out.println("subdataset_count: " + subdataset_count);

		for (int i = 0; i < tempDataset.getWorkerSize(); i++) {
			//为每个工人找相似工人
			String id = tempDataset.getWorkerByIndex(i).getId();

				for (int j = 0; j < tempDataset.getWorkerSize(); j++) {
					String id1 = tempDataset.getWorkerByIndex(i).getId();
					String id2 = tempDataset.getWorkerByIndex(j).getId();
					if (i == j) {
						maxtri[i][j] = -1;
					} else {
						maxtri[i][j] = calSimilarity(attributeW.get(id1), attributeW.get(id2));
					}
				}
				double[] findK = maxtri[i];

				for (int k = 0; k < numK; k++) {
					similarKWorker[i][k] = Utils.maxIndex(findK);
					distanceWorker[i][k] = findK[Utils.maxIndex(findK)];
					findK[Utils.maxIndex(findK)] = Double.MIN_VALUE;
				}


					workercounts[1]++;
					//Dataset extend_dataset = new Dataset(dataset, 0);
					//保存工人的K个相似工人的id
					//遍历所有实例，找出要使用的实例——工人自己标注的和相似工人标注的实例以及标签
					for(int j = 0; j < tempDataset.getExampleSize(); j++) {
						Example example = tempDataset.getExampleByIndex(j);
						//存储实例的加权类概率分布
						double[] labelDistribution = new double[tempDataset.getCategorySize()];
						for(int k=0; k < numK; k++) {
							int workerindex = similarKWorker[i][k];
							Worker worker = tempDataset.getWorkerByIndex(workerindex);
							if(example.getNoisyLabelByWorkerId(worker.getId()) != null){
								int value = example.getNoisyLabelByWorkerId(worker.getId()).getValue();
								labelDistribution[value] += distanceWorker[i][k] ;

							}
						}
						//System.out.println("labelDistribution: " + Arrays.toString(labelDistribution));

						double sum = Utils.sum(labelDistribution);
						if (Utils.eq(sum, 0.0)) {
							continue;
						}
						for (int k = 0; k < labelDistribution.length; k++) {
							labelDistribution[k] = (labelDistribution[k]) / (sum);
						}
						for (int k = 0; k < labelDistribution.length; k++) {
							if(Utils.eq(0.0, labelDistribution[k])) {
								continue;
							}
							Example example1 = new Example(example, UUID.randomUUID().toString());
							example1.setWeight(labelDistribution[k]);
							example1.setIntegratedLabel(new Label(null, k+"", example1.getId(), "null"));

							sub_dataset.get(id).addExample(example1);
						}
					}
						sub_dataset.get(id).assignIntegeratedLabel2WekaInstanceClassValue();

						subdataset_count.replace(id, sub_dataset.get(id).getExampleSize());

						RandomForest j48 = new RandomForest();

						j48.buildClassifier(sub_dataset.get(id));

						sub_classifier.put(id, j48);

		}

		System.out.println("worker count: " + Arrays.toString(workercounts));
		System.out.println("aftercount: " + subdataset_count);



		//Label completion
		HashMap<String,Double> preacc = new HashMap<String, Double>();
		HashMap<String,Double> precount = new HashMap<String, Double>();
		int count = 0;

		int T=0,F=0;

		for (int i = 0; i < tempDataset.getExampleSize(); i++) {
			Example example = dataset.getExampleByIndex(i);
			Example e = tempDataset.getExampleByIndex(i);


			ArrayList<String> worker = e.getWorkerIdList();

			for (int j = 0; j < tempDataset.getWorkerSize(); j++) {
				String id = tempDataset.getWorkerByIndex(j).getId();
				Worker w = tempDataset.getWorkerByIndex(j);
				//if(is_highquality[j]){
				//if(sub_classifier.containsKey(id)) {
				if (!precount.containsKey(id)) {
					precount.put(id, 0.0);
				}
				if (!preacc.containsKey(id)) {
					preacc.put(id, 0.0);
				}
					if (!worker.contains(id)) {

						double[] distributionForInstance = sub_classifier.get(id).distributionForInstance(example);

						double max1 = distributionForInstance[Utils.maxIndex(distributionForInstance)];
						Integer q1 = Utils.maxIndex(distributionForInstance);
						distributionForInstance[Utils.maxIndex(distributionForInstance)] = -1;
						double max2 = distributionForInstance[Utils.maxIndex(distributionForInstance)];

						if((max1-max2) >= 1.0/m_numClasses) {
							Label label = new Label(null, q1.toString(), e.getId(), id);
							e.addNoisyLabel(label);
							w.addNoisyLabel(label);
							precount.replace(id, precount.get(id) + 1);

							if(q1 == e.getTrueLabel().getValue()) {
								preacc.replace(id, preacc.get(id) + 1);
								T += 1;
							}
							else {
								F+=1;
							}
						}
					}
				//}
			}
		}

		HashMap<String,Double> preacccal = new HashMap<String, Double>();
		for(int i = 0 ; i < tempDataset.getWorkerSize(); i++) {
			String id = tempDataset.getWorkerByIndex(i).getId();
			if(!preacccal.containsKey(id))
				preacccal.put(id, 0.0);
			if(sub_classifier.containsKey(id)) {
				double acc = preacc.get(id) / precount.get(id);
				preacccal.replace(id, acc);
			}
		}
		System.out.println("PredictionTrue:  " + preacc);
		System.out.println("PredictionCount:  " + precount);
		System.out.println("PredictionAcc:  " + preacccal);
		System.out.println(preacccal.size());
		double acc = (double) T / (T+F);
		System.out.println("\n完整算法：正确补全" + T + "，错误补全" + F + "补全正确率为： " + acc);


		//

		return tempDataset;
	}

	//Calculating worker similarity (cosine similarity)
	public static double calSimilarity(double[] w1, double[] w2) {
		double s = 0;
		double fenzi = 0;
		double fenmu1 = 0;
		double fenmu2 = 0;
		for (int i = 0; i < w1.length; i++) {
			fenzi += w1[i] * w2[i];
			fenmu1 += w1[i] * w1[i];
			fenmu2 += w2[i] * w2[i];
		}
		if(fenzi==0||fenmu1==0||fenmu2==0){
			return 0;
		} else {
			s = fenzi / (Math.sqrt(fenmu1) * Math.sqrt(fenmu2));
			return 0.5 * (1 + s);
		}
	}


	//计算工人特征向量
	public static double[] calAttributeW(Dataset data, String id) throws Exception {
		Instances instances = new Instances(data);
		instances.setClassIndex(instances.numAttributes()-1);
		Dataset dataset = copyDataset(data);
		int numDataset = instances.numInstances();
		int numClass = instances.numClasses();
		//worker's feature vector
		double[] r = new double[instances.numAttributes()-1];
		//class probability distribution
		double[] pc = new double[numClass];
		double[][] classy = new double[numClass][numDataset];
		for (int j = 0; j < instances.numInstances(); j++) {
			Example example = dataset.getExampleByIndex(j);
			Instance instance = instances.instance(j);
			double Class = example.getNoisyLabelByWorkerId(id).getValue();
			instance.setClassValue(Class);
			pc[(int)Class]++;
			classy[(int)Class][j] = 1;
		}
		myNormalize(pc, numDataset);
		for (int i = 0; i < instances.numAttributes()-1; i++) {
			int numAtt = instances.attribute(i).numValues();
			double[][] attx = new double[numAtt][numDataset];
			double[] attx2 = new double[numDataset];
			double[][] paic = new double[numAtt][numClass];
			if (instances.attribute(i).isNominal()) {
				for (int j = 0; j < numDataset; j++) {
					Instance instance = instances.instance(j);
					paic[(int) instance.value(i)][(int) instance.classValue()]++;
					attx[(int) instance.value(i)][j]=1;
				}
			} else {
				for (int j = 0; j < numDataset; j++) {
					attx2[j] = instances.instance(j).value(i);
				}
			}
			//Calculate the correlation coefficient
			if (instances.attribute(i).isNominal()) {
				for (int q = 0; q < numClass; q++) {
					for (int p = 0; p < numAtt; p++) {
						paic[p][q] /= numDataset;
						if (paic[p][q] != 0) {
							r[i] += paic[p][q] * calAttributeR(attx[p], classy[q]);
						}
					}
				}
			} else {
				for (int q = 0; q < numClass; q++) {
					if(pc[q]!=0) {
						r[i] += pc[q] * calAttributeR(attx2, classy[q]);
					}
				}
			}
		}
		return r;
	}

	//Calculate Pearson’s correlation
	public static double calAttributeR(double[] x, double[] y) throws Exception {
		double r = 0;
		double meanx = Utils.mean(x);
		double meany = Utils.mean(y);
		double fenzi = 0;
		double fenmu1 = 0;
		double fenmu2 = 0;
		for(int i = 0; i < x.length; i++) {
			fenzi += (x[i] - meanx)*(y[i] - meany);
			fenmu1 += Math.pow(x[i] - meanx,2);
			fenmu2 += Math.pow(y[i] - meany,2);
		}
		r = fenzi / (Math.sqrt(fenmu1) * Math.sqrt(fenmu2));
		if(Double.isNaN(r)) {
			r=0;
		}
		return r;
	}

	//Transformation into a probability distribution
	public static double[] myNormalize(double[] doubles, int numInstances) {
		for(int i = 0; i < doubles.length; ++i) {
			doubles[i] = doubles[i] / numInstances;
		}
		return doubles;
	}

	public static Dataset copyDataset(Dataset dataset) {
		Dataset copyDataset = new Dataset(dataset, 0);
		for (int k = 0; k < dataset.getExampleSize(); k++) {
			Example example = dataset.getExampleByIndex(k);
			copyDataset.addExample(example);
		}
		for (int k = 0; k < dataset.getCategorySize(); k++) {
			Category category = dataset.getCategory(k);
			copyDataset.addCategory(category);
		}
		for (int k = 0; k < dataset.getWorkerSize(); k++) {
			Worker worker = dataset.getWorkerByIndex(k);
			copyDataset.addWorker(worker);
		}
		return copyDataset;
	}




}