package ceka.consensus.other.SLLC_paper;

import ceka.consensus.MajorityVote;
import ceka.consensus.gtic.GTIC;
import ceka.consensus.other.AALI.AALI;
import ceka.consensus.other.DEWSMV.OptimizedError;
import ceka.consensus.other.MNLDP.MNLDP;
import ceka.consensus.other.SCLI.SLLI;
import ceka.consensus.other.SLLC.NBLC_onlysimi;
import ceka.consensus.other.TDLI.TDLI;
import ceka.consensus.other.WSLC.wslc;
import ceka.converters.FileLoader;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.utils.CekaUtils;
import myqpmatlab.MyQP;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;


public class test_real {
    private static Dataset m_dataset=null;
    private static Dataset m_dataset2=null;

    //private static String [] dataname={"leaves"};

    private static String dataSetArffDir = "F:\\DRP\\data\\real-world\\";

    private static String[] dataSetArddFix = {"leaves","income94L10","music_31","labelme"}; //"leaves","income94L10","music_31","labelme"
    //private static String[] dataSetArddFix = {"leaves/leaves"};
    //private static String[] dataSetArddFix = new File(dataSetArffDir).list();

    private static String runDir = "F:\\DRP\\Result\\SLLC/";

    private static int times = 10;

//    public void readData(int m_choose) throws Exception {
//        String arffxPath="F:\\DRP\\data\\real-world\\"+dataname[m_choose]+ "\\" +dataname[m_choose] +".arffx";
//        String responsePath="F:\\DRP\\data\\real-world\\"+dataname[m_choose]+  "\\" +dataname[m_choose] +".response.txt";
//        String goldPath="F:\\DRP\\data\\real-world\\"+dataname[m_choose]+  "\\" +dataname[m_choose] +".gold.txt";
//        m_dataset = FileLoader.loadFileX(responsePath, goldPath, arffxPath);
//
//    }

    public static Dataset Datasetcopy(Dataset dataset) {
        Dataset newdataset = dataset.generateEmpty();
        int numCateSize = dataset.getCategorySize();
        for (int i = 0; i < numCateSize; i++) {
            Category cate = dataset.getCategory(i);
            newdataset.addCategory(cate.copy());
        }
        for (int j = 0; j < dataset.getExampleSize(); j++) {
            Example example = dataset.getExampleByIndex(j);
            newdataset.addExample(example);
        }
        for (int i = 0; i < dataset.getWorkerSize(); i++) {
            newdataset.addWorker(dataset.getWorkerByIndex(i));
        }
        return newdataset;
    }

    public double integrationAccuracy(Dataset dataset) {
        int numCleanExample = 0;
        for (int i = 0; i < dataset.getExampleSize(); i++) {
            Example example = dataset.getExampleByIndex(i);
            if (example.getIntegratedLabel().getValue() == example.getTrueLabel().getValue())
                numCleanExample++;
        }
        return numCleanExample / (double) dataset.getExampleSize();
    }

    public static void main(String[] args) throws Exception{


        File testDir = new File(runDir);
        if (!testDir.exists())
            testDir.mkdirs();

        // write the result to a file
        //FileOutputStream f_i = new FileOutputStream(new File(runDir + "result_F1.txt"));
        FileOutputStream f_c = new FileOutputStream(new File(runDir + "test_r.txt"));
        // PrintStream result_i = new PrintStream(f_i);
        PrintStream result_c = new PrintStream(f_c);
        //String outputPath = "E:\\研一\\result\\DVKNN_result\\outputTemp\\";

        result_c.format("%-30s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s",
                "Dataset", "MV-WSLC", "SLLC", "GTIC-WSLC", "SLLC",
                "DEWSMV-WSLC", "DEWSMV-SLLC", "MNLDP-WSLC", "SLLC",
                "AALI-WSLC", "SLLC", "SLLI-WSLC",  "SLLC");
        result_c.println();

        double meanIntegrationMV = 0;
        double meanIntegrationGTIC = 0.0;
        double meanIntegrationDEWSMV = 0.0;
        double meanIntegrationMNLDP = 0.0;
        double meanIntegrationAALI = 0.0;
        double meanIntegrationSLLI = 0.0;

        double meanIntegrationMV2 = 0;
        double meanIntegrationGTIC2 = 0.0;
        double meanIntegrationDEWSMV2 = 0.0;
        double meanIntegrationMNLDP2 = 0.0;
        double meanIntegrationAALI2 = 0.0;
        double meanIntegrationSLLI2 = 0.0;

            for (int index = 0; index < dataSetArddFix.length; index++) {

                String arffxPath = dataSetArffDir + dataSetArddFix[index] +"\\" + dataSetArddFix[index] + ".arffx";
                String arffPath = dataSetArffDir + dataSetArddFix[index] +"\\" + dataSetArddFix[index] + ".arff";
                String responsePath=dataSetArffDir + dataSetArddFix[index] +"\\"  + dataSetArddFix[index] + ".response.txt";
                String goldPath=dataSetArffDir + dataSetArddFix[index] + "\\" + dataSetArddFix[index] + ".gold.txt";

                Dataset dataset;
                //Dataset dataset2;
                try {
                    m_dataset = FileLoader.loadFileX(responsePath, goldPath, arffxPath);
                    m_dataset2 = FileLoader.loadFileX(responsePath, goldPath, arffxPath);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
//					e.printStackTrace();
                    m_dataset = FileLoader.loadFile(responsePath, goldPath, arffPath);
                    m_dataset2 = FileLoader.loadFile(responsePath, goldPath, arffPath);
                }

                System.out.println(dataSetArddFix[index]);

                double IntegrationMV = 0;
                double IntegrationGTIC = 0;
                double IntegrationDEWSMV = 0;
                double IntegrationMNLDP = 0;
                double IntegrationAALI = 0;
                double IntegrationSLLI = 0;

                double IntegrationMV2 = 0;
                double IntegrationGTIC2 = 0;
                double IntegrationDEWSMV2 = 0;
                double IntegrationMNLDP2 = 0;
                double IntegrationAALI2 = 0;
                double IntegrationSLLI2 = 0;

                for (int m = 1 ; m <= 1; m++) {
                    test_real expriment = new test_real();

                    wslc similarity1 = new wslc();
                    m_dataset = similarity1.doInference(m_dataset);

                    SLLC similarity = new SLLC();
                    //NBLC similarity = new NBLC();
                    m_dataset2 = similarity.doInference(m_dataset2,15);

                    // Majority Voting
                    Dataset tempDataMV = CekaUtils.datasetCopy(m_dataset);
                    MajorityVote mv = new MajorityVote();
                    mv.doInference(tempDataMV);
                    IntegrationMV += expriment.integrationAccuracy(tempDataMV)  * 100 ;

                    Dataset tempDataMV2 = CekaUtils.datasetCopy(m_dataset2);
                    MajorityVote mv2 = new MajorityVote();
                    mv2.doInference(tempDataMV2);
                    IntegrationMV2 += expriment.integrationAccuracy(tempDataMV2)  * 100 ;


                  // GTIC
                    Dataset datasetGTIC = CekaUtils.datasetCopy(m_dataset);
                    GTIC gtic = new GTIC("E:\\\\研一\\\\result\\\\run\\\\");
                    gtic.doInference(datasetGTIC);
                    IntegrationGTIC += expriment.integrationAccuracy(datasetGTIC) * 100 ;

                    Dataset datasetGTIC2 = CekaUtils.datasetCopy(m_dataset2);
                    GTIC gtic2 = new GTIC("E:\\\\研一\\\\result\\\\run\\\\");
                    gtic2.doInference(datasetGTIC2);
                    IntegrationGTIC2 += expriment.integrationAccuracy(datasetGTIC2) * 100 ;

                    //DEWSMV
                    Dataset tempDataDEWSMV = Datasetcopy(m_dataset);
                    OptimizedError dewsmv = new OptimizedError();
                    dewsmv.DE_search(tempDataDEWSMV);
                    IntegrationDEWSMV += expriment.integrationAccuracy(tempDataDEWSMV)  * 100 ;

                    Dataset tempDataDEWSMV2 = Datasetcopy(m_dataset2);
                    OptimizedError dewsmv2 = new OptimizedError();
                    dewsmv2.DE_search(tempDataDEWSMV2);
                    IntegrationDEWSMV2 += expriment.integrationAccuracy(tempDataDEWSMV2)  * 100 ;

                    // MNLDP
                    Dataset datasetMNLDP = CekaUtils.datasetCopy(m_dataset);
                    MNLDP mnldp = new MNLDP();
                    MyQP t24 = new MyQP();
                    mnldp.setMyQP(t24);
                    mnldp.doInference(datasetMNLDP);
                    t24.dispose();
                    IntegrationMNLDP += expriment.integrationAccuracy(datasetMNLDP)  * 100 ;

                    Dataset datasetMNLDP2 = CekaUtils.datasetCopy(m_dataset2);
                    MNLDP mnldp2 = new MNLDP();
                    MyQP t2 = new MyQP();
                    mnldp2.setMyQP(t2);
                    mnldp2.doInference(datasetMNLDP2);
                    t2.dispose();
                    IntegrationMNLDP2 += expriment.integrationAccuracy(datasetMNLDP2)  * 100 ;

                    Dataset datasetAALI = CekaUtils.datasetCopy(m_dataset);
                    AALI aali = new AALI();
                    datasetAALI=aali.doInference(datasetAALI);
                    IntegrationAALI += expriment.integrationAccuracy(datasetAALI)  * 100 ;

                    Dataset datasetAALI2 = CekaUtils.datasetCopy(m_dataset2);
                    AALI aali2 = new AALI();
                    datasetAALI2=aali2.doInference(datasetAALI2);
                    IntegrationAALI2 += expriment.integrationAccuracy(datasetAALI2)  * 100 ;

                    System.out.println("SCLI_set....");
                    Dataset datasetSCLI_set = CekaUtils.datasetCopy(m_dataset);
                    SLLI scli_set = new SLLI();
                    datasetSCLI_set = scli_set.doInference(datasetSCLI_set);
                    IntegrationSLLI += expriment.integrationAccuracy(datasetSCLI_set)  * 100 ;

                    Dataset datasetSCLI_set2 = CekaUtils.datasetCopy(m_dataset2);
                    SLLI scli_set2 = new SLLI();
                    datasetSCLI_set2 = scli_set2.doInference(datasetSCLI_set2);
                    IntegrationSLLI2 += expriment.integrationAccuracy(datasetSCLI_set2) * 100 ;

                }
//                IntegrationMV /= 10;
//                IntegrationGTIC /= 10;
//                IntegrationDEWSMV /= 10;
//                IntegrationMNLDP /= 10;
//                IntegrationAALI /= 10;
//                IntegrationSLLI /= 10;
//
//
//                IntegrationMV2 /= 10;
//                IntegrationGTIC2 /= 10;
//                IntegrationDEWSMV2 /= 10;
//                IntegrationMNLDP2 /= 10;
//                IntegrationAALI2 /= 10;
//                IntegrationSLLI2 /= 10;

                meanIntegrationMV += IntegrationMV;
                meanIntegrationGTIC += IntegrationGTIC;;
                meanIntegrationDEWSMV += IntegrationDEWSMV;
                meanIntegrationMNLDP += IntegrationMNLDP;
                meanIntegrationAALI += IntegrationAALI;
                meanIntegrationSLLI += IntegrationSLLI;


                meanIntegrationMV2 += IntegrationMV2;
                meanIntegrationGTIC2 += IntegrationGTIC2;
                meanIntegrationDEWSMV2 += IntegrationDEWSMV2;
                meanIntegrationMNLDP2 += IntegrationMNLDP2;
                meanIntegrationAALI2 += IntegrationAALI2;
                meanIntegrationSLLI2 += IntegrationSLLI2;


                result_c.format("%-30s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataSetArddFix[index],
                        IntegrationMV, IntegrationMV2, IntegrationGTIC, IntegrationGTIC2,
                        IntegrationDEWSMV, IntegrationDEWSMV2, IntegrationMNLDP, IntegrationMNLDP2,
                        IntegrationAALI, IntegrationAALI2, IntegrationSLLI, IntegrationSLLI2);
                result_c.println();
            }

            meanIntegrationMV /= dataSetArddFix.length;
            meanIntegrationGTIC /= dataSetArddFix.length;
            meanIntegrationDEWSMV /= dataSetArddFix.length;
            meanIntegrationMNLDP /= dataSetArddFix.length;
            meanIntegrationAALI /= dataSetArddFix.length;
            meanIntegrationSLLI /= dataSetArddFix.length;


            meanIntegrationMV2 /= dataSetArddFix.length;
            meanIntegrationGTIC2 /= dataSetArddFix.length;
            meanIntegrationDEWSMV2 /= dataSetArddFix.length;
            meanIntegrationMNLDP2 /= dataSetArddFix.length;
            meanIntegrationAALI2 /= dataSetArddFix.length;
            meanIntegrationSLLI2 /= dataSetArddFix.length;

            result_c.format("%-30s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f ","Mean",
                    meanIntegrationMV, meanIntegrationMV2,  meanIntegrationGTIC, meanIntegrationGTIC2,
                    meanIntegrationDEWSMV,meanIntegrationDEWSMV2, meanIntegrationMNLDP,meanIntegrationMNLDP2,
                    meanIntegrationAALI, meanIntegrationAALI2, meanIntegrationSLLI, meanIntegrationSLLI2);
            result_c.println();
            result_c.close();

    }

}



